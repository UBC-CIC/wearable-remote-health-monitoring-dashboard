const AWS = require('aws-sdk');

/*
*   Description: Saves the Device into Device Table (DynamoDB)
*   Required Inputs: deviceID, deviceOS
*   Expected Output: No return value. Adds device entry to DynamoDB "Device" table.
 */
const registerDevice = async (device) => {
    return new Promise(function(resolve, reject) {

        // Extract the relevant fields from the payload
        const { deviceID, deviceOS} = device;


        // Initialize the DynamoDB DocumentClient
        const documentClient = new AWS.DynamoDB.DocumentClient({region: process.env.AWS_REGION});
        let params = {
            TableName: process.env.DEVICE_TABLE,
            Item: {
                id: deviceID,
                deviceOS: deviceOS,
                deviceStatus: "Ready",
                updatedAt: new Date().toISOString(),
            }
        }

        documentClient.put(params, function(err, data) {
            if (err) {
                console.log("Error: A problem occurred registering the device: ", err);
                reject(err);
            }
            else {
                resolve();
            }
        });

    });

}

module.exports = registerDevice;