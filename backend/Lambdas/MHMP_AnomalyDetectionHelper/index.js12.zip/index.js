'use strict';
const AWS = require('aws-sdk');

/*
*   Description: Processes recent historical data for heart rate anomalies. Runs every 5 minutes.
*   Expected Output: No return value. Generates an Alert for heart rate anomalies, and updates device status.
 */
exports.handler = async (event) => {


    // Set the AWS region
    AWS.config.update({region: process.env.AWS_REGION});
    // initialize AWS DynamoDB Document Client instance
    const documentClient = new AWS.DynamoDB.DocumentClient({apiVersion: '2012-08-10'});
    // search parameters

    try{
        //==================================---Fetch List Of Users---======================================

        // fetches list of user IDs and associated device IDs (if any)
        let users = await fetchUsersHelper(documentClient);
        console.log("users retrieved: ", users);

        //=============================---Fetch Device Data Output For each User---=========================
        for (let user of users) {
            let heartRateData = await fetchData(documentClient, user.id, "heart_rate");
            console.log("Retrieved heart rate data: ", heartRateData);
        }

    } catch (err) {
        console.log("Error: Anomaly detection failed with error: ", err);
    }
    

};


//=========================================---Helper Functions---=========================================

// fetches users that have an associated device
const fetchUsersHelper = async (documentClient) => {
    return new Promise(function(resolve, reject) {
        // search parameters
        let params = {
            TableName: process.env.USER_TABLE,
            ProjectionExpression: "id, userDeviceId",
            FilterExpression: "attribute_exists(#deviceID)",
            ExpressionAttributeNames: {
                "#deviceID": "userDeviceId"
            }
        };

        documentClient.scan(params, function(err, data) {
            if (err) {
                console.log(err, err.stack); // an error occurred
                reject(err);
            } else {
                // successful response
                resolve(data.Items);
            }
        });
    });
}


// fetches data for a given user and a given data type
const fetchData = async (documentClient, userId, datatype) => {
    return new Promise(function(resolve, reject) {
        let timeInterval  = 10;
        let currentDateTime = new Date().toISOString();
        let prevDateTime = new Date(new Date().getTime() - timeInterval*60000).toISOString();
        let params = {
            TableName: process.env.DATA_TABLE,
            IndexName: "byUserIDAndObservationType",
            KeyConditionExpression: "#UserId = :user_id AND #Range BETWEEN :rangeStart AND :rangeEnd",
            ProjectionExpression: "userID, observationValue, observationUnit, createdAt",
            /*FilterExpression: "#type = :dataType",*/
            ExpressionAttributeNames: {
                "#UserId" : "userID",
                "#Range": "observationType#createdAt"
            },
            ExpressionAttributeValues: {
                ":rangeStart": datatype.concat("-").concat(prevDateTime),
                ":rangeEnd": datatype.concat("-").concat(currentDateTime),
                ":user_id": userId,
                /*":start_time": prevDateTime,
                ":end_time": currentDateTime*/
            }
        };

        documentClient.query(params, function(err, data) {
            if (err) {
                console.log(err, err.stack); // an error occurred
                reject(err);
            } else {
                // successful response
                console.log("data: ", data);
                resolve(data.Items);
            }
        });

    });
}