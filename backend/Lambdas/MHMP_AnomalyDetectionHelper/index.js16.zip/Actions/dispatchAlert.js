const AWS = require('aws-sdk');
const appsync = require('aws-appsync');
const { AUTH_TYPE } = require('aws-appsync-auth-link');
const gql = require('graphql-tag');
require('cross-fetch/polyfill');

/*
*   Description: Creates an Alert in DynamoDB when triggered by an anomaly detection.
*   Required Inputs: userID, deviceID, type, description, createdAt
*   Expected Output: No return value.
 */
const dispatchAlert = async (alertData) => {
    return new Promise(function(resolve, reject) {

        const {userID, deviceID, type, description, createdAt} = alertData;

        let data = fetchDeviceInfoHelper(deviceID);

        // check if the device status is already set to "HeartRate_Anomaly", if so we don't need
        // to generate another alert
        if (data.deviceStatus === "HeartRate_Anomaly") {
            return;
        }

        let location = data.lastLocation;

        const graphqlClient = new appsync.AWSAppSyncClient({
            url: process.env.GRAPHQL_ENDPOINT,
            region: process.env.AWS_REGION,
            auth: {
                type: AUTH_TYPE.AWS_IAM,
                credentials: AWS.config.credentials,
            },
            disableOffline: true
        });

        const mutation = gql`mutation createAlert($input: CreateAlertInput!) {
            createAlert(input: $input) {
                createdAt
                description
                userID
                type
                id
                location {
                    lat
                    lng
                }
                expirationTime
                updatedAt
            }
        }`;
        graphqlClient.mutate({
            mutation,
            variables: {
                input: {
                    userID: userID,
                    type: type,
                    description: description,
                    location: location,
                    createdAt: createdAt,
                    expirationTime: Math.floor(new Date().getTime()/1000.0)+604800 //TTL: expire after a week
                }
            }
        }).then(data => {
            resolve();
        }).catch(err => {
            console.log("Error generating new alert: ", err);
            reject("Error generating new alert: ", err);
        });

    });
}

//================================================---Helper Functions---==========================================

// fetch user's latest location if it exists
const fetchDeviceInfoHelper = async (deviceID) => {
    return new Promise(function(resolve, reject) {

        // initialize AWS DynamoDB Document Client instance
        const documentClient = new AWS.DynamoDB.DocumentClient({apiVersion: '2012-08-10'});


        // search parameters
        let params = {
            TableName: process.env.DEVICE_TABLE,
            Key: {
                'id': deviceID
            },
            ProjectionExpression: "lastLocation, deviceStatus",
        };

        documentClient.get(params, function(err, data) {
            if (err) {
                console.log(err, err.stack); // an error occurred
                reject(err);
            } else {
                // successful response
                resolve(data.Item);
            }
        });
    });
}

//==============================================================================================================

module.exports = dispatchAlert;