'use strict';
const AWS = require('aws-sdk');
const processHeartRate = require("./Processing/processHeartRate.js");

/*
*   Description: Processes recent historical data for heart rate anomalies. Runs every 5 minutes.
*   Expected Output: No return value. Generates an Alert for heart rate anomalies, and updates device status.
 */
exports.handler = async (event) => {


    // Set the AWS region
    AWS.config.update({region: process.env.AWS_REGION});
    // initialize AWS DynamoDB Document Client instance
    const documentClient = new AWS.DynamoDB.DocumentClient({apiVersion: '2012-08-10'});


    try{
        //==================================---Fetch List Of Users---======================================

        // fetches list of user IDs and associated device IDs (if any)
        let users = await fetchUsersHelper(documentClient);


        //=============================---Fetch Device Data Output For each User---=========================

        // fetch heart rate data for each user
        for (let user of users) {
            let heartRateData = await fetchData(documentClient, user.id, "heart_rate");
            console.log("Retrieved heart rate data: ", heartRateData);
            // guard against null/undefined return value
            if (heartRateData) {
               if (heartRateData.length !== 0) {
                   // process data
                   //await processHeartRate(heartRateData);
               }
            }
        }

    } catch (err) {
        console.log("Error: Anomaly detection failed with error: ", err);
    }
    

};


//=========================================---Helper Functions---=========================================

// fetches users that have an associated device
const fetchUsersHelper = async (documentClient) => {
    return new Promise(function(resolve, reject) {
        // search parameters
        let params = {
            TableName: process.env.USER_TABLE,
            ProjectionExpression: "id, userDeviceId",
            FilterExpression: "attribute_exists(#deviceID)",
            ExpressionAttributeNames: {
                "#deviceID": "userDeviceId"
            }
        };

        documentClient.scan(params, function(err, data) {
            if (err) {
                console.log(err, err.stack); // an error occurred
                reject(err);
            } else {
                // successful response
                resolve(data.Items);
            }
        });
    });
}


// fetches data for a given user and a given data type
const fetchData = async (documentClient, userID, observationType) => {
    return new Promise(function(resolve, reject) {

        let timeInterval  = 5;
        let dateTimeEnd = new Date().toISOString();
        let dateTimeStart = new Date(new Date().getTime() - timeInterval*60000).toISOString();
        console.log("dateTimeStart: ", dateTimeStart);
        console.log("observationType#createdAt: ", observationType.concat("#" + dateTimeStart))
        console.log("userID: ", userID);

        let params = {
            TableName: process.env.DATA_TABLE,
            IndexName: "byUserIDAndObservationType",
            KeyConditionExpression: "#userID = :userID AND #Range BETWEEN :rangeStart AND :rangeEnd",
            ProjectionExpression: "userID, observationValue, observationUnit, createdAt",
            ExpressionAttributeNames: {
                "#userID" : "userID",
                "#Range": "observationType#createdAt"
            },
            ExpressionAttributeValues: {
                ":rangeStart": observationType.concat("#" + dateTimeStart),
                ":rangeEnd": observationType.concat("#" + dateTimeEnd),
                ":userID": userID,
            }
        };

        /*let params = {
            TableName: process.env.DATA_TABLE,
            IndexName: "byUserID",
            KeyConditionExpression: "#userID = :userID AND #createdAt >= :rangeStart",
            ProjectionExpression: "userID, observationValue, observationUnit, createdAt",
            FilterExpression: "#observationType = :observationType",
            ExpressionAttributeNames: {
                "#userID" : "userID",
                "#createdAt": "createdAt",
                "#observationType": "observationType"
            },
            ExpressionAttributeValues: {
                ":rangeStart": dateTimeStart,
                ":userID": userID,
                ":observationType": observationType,
            }
        };*/

        /*let params = {
            TableName: process.env.DATA_TABLE,
            IndexName: "byUserID",
            KeyConditionExpression: "#UserId = :user_id",
            ProjectionExpression: "userID, deviceID, observationValue, observationUnit, createdAt",
            FilterExpression: "#Type = :dataType AND #Time > :time",
            ExpressionAttributeNames: {
                "#UserId" : "userID",
                "#Type": "observationType",
                '#Time': "updatedAt",
            },
            ExpressionAttributeValues: {
                ":dataType": observationType,
                ":user_id": userId,
                ":time": prevDateTime,
            }
        };*/


        documentClient.query(params, function(err, data) {
            if (err) {
                console.log(err, err.stack); // an error occurred
                reject(err);
            } else {
                // successful response
                resolve(data.Items);
            }
        });

    });
}